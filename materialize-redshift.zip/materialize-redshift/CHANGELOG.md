# materialize-redshift

## v1, 2023-03-10
- Beginning of changelog.

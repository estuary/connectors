package main

import boilerplate "github.com/estuary/connectors/materialize-boilerplate"

func main() {
	boilerplate.RunMain(newRedshiftDriver())
}

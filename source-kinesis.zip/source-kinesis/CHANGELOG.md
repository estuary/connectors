# source-kinesis

## v1, 2022-07-27
- Beginning of changelog.
